Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_header("MSA_DeviceTicket", 
		"t=EwCwAlN5BAAUu1V9OkIAK55tj6h8OjaXgvkszYkAAe5Saa2yxWzHul8zZWZv5n//x58/zcs2Ri3zwLKaKdmbkWuo7QTBIaHJi5b9zEWyCOgy6mhnF9noDy+Qx8NcSAlcvlFz8eiH6ZUXnuER18rD2Lyfz8J6cFIsZvueHxUMXr64N7JER1//SJcQlM56kEmNxTL/lfP3HSIjHCHQC3OK1Js5+/bXEwIByUJwwTR2g7tTd9Bvo4tRNHZoYDuBUwcLx8+YAwnc1YfcWZ62/vhrRvSHQB6V7AKaJsxffU504ziwgkIfrdf3avjTMPSsfrDct41RHfZfjvcaXJV43aErciI9+6XB36eIVwPNnlDPO4+ii4oydfDmpn+/JXBeo3wDZgAACPdPl3vDZw45gAGZm335pBsPpGy8cKXJ8OKSKvSqcCpIcRX+txhVC9uI/oixsJO+"
		"R4Dgk1qh1WhNMc6PWp9Nywha1XZFlTU1WBxtb0y9r9JrfCBAFjXnL83Y3WTI9nNih8VJXsKz609NkNX686w8Icz5YU2lx3+DXB0q5kd7IeN62H5GT+pjnd4EqJkNa9elTTCevT7cYgMJe3gIqNCH5ElyDr3ifx8SM3SPQ+pPM9edlaAKRTPN+dkdMmiTWwoYa8U8CntW77Xz5aNQFm8j3VwXMspJVf20Yv+cewTia9OXeJjae5I/EIJHeDGniyb6jYEFeuUCKEBC75A18ZO2noR1Pb9xUwX+4ITP38hyhliTHY/vinsEFiv7JQYTSrBxk3Cb8U1xvBZLWz+5YzuOz7UkDm05XXJsZI9L4cNGHHIbFRE8IaNFtv0xdmAmZRte5F36i6TyX7byEcsGJ+kjWBiwidjF6D8pd73lafT4tmQL78HHMjuhw2DPGBYAHWOq2NgEf502OIHy7NW4AQ==&p=");

	web_custom_request("Telemetry.Request", 
		"URL=https://nw-umwatson.events.data.microsoft.com/Telemetry.Request", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTTP", 
		"EncType=application/xml", 
		"BodyBinary=t\\x0E\\x00\\x00<?xml version=\"1.0\"?>\n<req ver=\"2\">\n <tlm>\n  <src>\n   <desc>\n    <mach>\n     <os>\n      <arg nm=\"vermaj\" val=\"10\"/>\n      <arg nm=\"vermin\" val=\"0\"/>\n      <arg nm=\"verbld\" val=\"19045\"/>\n      <arg nm=\"vercsdbld\" val=\"3570\"/>\n      <arg nm=\"verqfe\" val=\"3570\"/>\n      <arg nm=\"csdbld\" val=\"3570\"/>\n      <arg nm=\"versp\" val=\"0\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"lcid\" val=\"1049\"/>\n      <arg nm=\"geoid\" "
		"val=\"203\"/>\n      <arg nm=\"sku\" val=\"48\"/>\n      <arg nm=\"domain\" val=\"0\"/>\n      <arg nm=\"portos\" val=\"0\"/>\n      <arg nm=\"ram\" val=\"7973\"/>\n      <arg nm=\"svolsz\" val=\"237\"/>\n      <arg nm=\"wimbt\" val=\"0\"/>\n      <arg nm=\"blddt\" val=\"191206\"/>\n      <arg nm=\"bldtm\" val=\"1406\"/>\n      <arg nm=\"bldbrch\" val=\"vb_release\"/>\n      <arg nm=\"os\" val=\"Windows\"/>\n      <arg nm=\"osver\" val=\"10.0.19041.3570.amd64fre.vb_release.191206-1406\"/>\n      "
		"<arg nm=\"buildflightid\" val=\"\"/>\n      <arg nm=\"expid\" val=\"\"/>\n      <arg nm=\"edition\" val=\"Professional\"/>\n     </os>\n     <hw>\n      <arg nm=\"form\" val=\"2\"/>\n      <arg nm=\"arch\" val=\"9\"/>\n      <arg nm=\"deviceclass\" val=\"Windows.Desktop\"/>\n      <arg nm=\"sysmfg\" val=\"HP\"/>\n      <arg nm=\"syspro\" val=\"HP 250 G8 Notebook PC\"/>\n      <arg nm=\"bv\" val=\"F.44\"/>\n      <arg nm=\"ram\" val=\"8192\"/>\n      <arg nm=\"proccnt\" val=\"4\"/>\n      <arg nm="
		"\"proclsp\" val=\"1190\"/>\n      <arg nm=\"wscpusc\" val=\"0\"/>\n      <arg nm=\"wsdsksc\" val=\"0\"/>\n      <arg nm=\"wscpudn\" val=\"Intel(R) Core(TM) i3-1005G1 CPU @ 1.20GHz\"/>\n      <arg nm=\"wsdgsc\" val=\"0\"/>\n      <arg nm=\"aoac\" val=\"0\"/>\n      <arg nm=\"bssku\" val=\"34N67ES#ACB\"/>\n      <arg nm=\"chid\" val=\"{deb6487c-6b8a-545b-851b-efe47e971600}\"/>\n      <arg nm=\"sdksz\" val=\"238\"/>\n     </hw>\n     <ctrl>\n      <arg nm=\"tm\" val=\"133428663138393060\"/>\n      "
		"<arg nm=\"mid\" val=\"BCDB43F5-54BC-47EF-91F2-31BB2D9F2A43\"/>\n      <arg nm=\"sample\" val=\"5006276\"/>\n      <arg nm=\"msft\" val=\"0\"/>\n      <arg nm=\"test\" val=\"0\"/>\n      <arg nm=\"scf\" val=\"0\"/>\n      <arg nm=\"commercialid\" val=\"\"/>\n      <arg nm=\"telemetry\" val=\"Optional\"/>\n     </ctrl>\n    </mach>\n   </desc>\n  </src>\n  <reqs>\n   <req key=\"1\">\n    <namespace svc=\"watson\" ptr=\"generic\" gp=\"generic\" app=\"msedge.exe\">\n     <arg nm=\"p1\" val=\""
		"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"118.0.2088.69\"/>\n     <arg nm=\"p3\" val=\"msedge_elf.dll\"/>\n     <arg nm=\"p4\" val=\"118.0.2088.69\"/>\n     <arg nm=\"p5\" val=\"3128439\"/>\n     <arg nm=\"p6\" val=\"utility\"/>\n     <arg nm=\"p7\" val=\"0x517a7ed\"/>\n     <arg nm=\"p8\" val=\"0\"/>\n    </namespace>\n    <ctrl>\n     <arg nm=\"reportid\" val=\"ade93b07-4f6d-4e10-a1c5-6c4d346771c5\"/>\n     <arg nm=\"procmeta.Channel\" val=\"\"/>\n     <arg nm=\"procmeta.MetricsClientId\" val=\""
		"08fb9279-622e-4959-a347-fc747f1d8ef3\"/>\n     <arg nm=\"procmeta.MetricsClientIdHash\" val=\"-7832272894290085809\"/>\n     <arg nm=\"procmeta.MetricsSessionId\" val=\"105\"/>\n     <arg nm=\"procmeta.OfficialBuild\" val=\"1\"/>\n     <arg nm=\"procmeta.RuntimeVariationsSeedETag\" val=\"&quot;yKFWLaCxbu6bw+z1FJQUaVWV133u6PDIAWRgNPg78rg=&quot;\"/>\n     <arg nm=\"procmeta.UXConfigCorrelationId\" val=\"AA0egBqKK7SemO/2eHUDTnpKpA3+iAL1NzHhTBWgrr4=\"/>\n     <arg nm=\"procmeta.VariationsSeedETag\" "
		"val=\"&quot;3aX49ofKxAeW/NIdueqYyNYCQzBxW7rQ/j3Mapzmexc=&quot;\"/>\n    </ctrl>\n    <cmd nm=\"event\">\n     <arg nm=\"eventtype\" val=\"crashpad_exp\"/>\n     <arg nm=\"cat\" val=\"generic\"/>\n     <arg nm=\"p1\" val=\"msedge.exe\"/>\n     <arg nm=\"p2\" val=\"118.0.2088.69\"/>\n     <arg nm=\"p3\" val=\"msedge_elf.dll\"/>\n     <arg nm=\"p4\" val=\"118.0.2088.69\"/>\n     <arg nm=\"p5\" val=\"3128439\"/>\n     <arg nm=\"p6\" val=\"utility\"/>\n     <arg nm=\"p7\" val=\"0x517a7ed\"/>\n     <arg"
		" nm=\"p8\" val=\"0\"/>\n     <arg nm=\"appsessionguid\" val=\"00003754-0001-001b-1364-0972a908da01\"/>\n    </cmd>\n   </req>\n  </reqs>\n </tlm>\n</req>\n", 
		LAST);

	lr_think_time(7);

	web_custom_request("nservice", 
		"URL=http://192.168.1.149:7678/nservice/", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTTP", 
		LAST);

	return 0;
}